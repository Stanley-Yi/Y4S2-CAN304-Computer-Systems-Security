# --- CAN304, CAN409 Lab  -----------------------------------------------------
# Lab 4: Advanced Cryptographic Schemes
#
# The YS-ECDH AKA protocol
# Party B
#
# COPYRIGHT (c) 2022 by Jie Zhang <jie.zhang01@xjtlu.edu.cn>
#
# -----------------------------------------------------------------------------


#import serial
import socket
import time
import random

from ecc.Key import Key
from ecc.elliptic import mul,add,neg

DOMAINS = {
    # Bits : (p, order of E(GF(P)), parameter b, base point x, base point y)
    256: (0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff,
          0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551,
          0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b,
          0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
          0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)
}

# longterm pk and sk
PKb = (29846905600001464966663618133187015030164722551698089320692285893856188332202,112351487829443581875216157205261801929997742409482132786966528895913005612787)
SKb = 32779072003454524014915441802223622479344852310970746569408979330270872501955
# longterm pk of responder
PKa = (19040945377468372801685031688616727966768327102472580671802632105133104724336,38156029207146965564095933110433162116638889566634802199987175781928072746123)

if __name__ == '__main__':

    global Ta,Rb,p,n,b,x,y,c_p,c_q,c_n,M1,M2,M3,Kb

    HOST = '127.0.0.1'
    PORT = 9002

    # initialization
    p, n, b, x, y=DOMAINS[256]
    c_p=3
    c_n=p
    c_q=p-b
    G = (int(x), int(y))
    idA='00000001'
    idB='00000002'
    token=0

    print('Begin')

    #TCP link
    sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sock.bind((HOST,PORT))

    print('Listen to the connection from initiator...')
    sock.listen(5)
    try:
        while (token==0):
            connection, address = sock.accept()
            print('Connected. Got connection from ', address)

            # 2. B receive M1 from A, compute Ub, and send M2=Ub to A
            M1=connection.recv(1024).decode()
            t1 = time.time()
            Ua = int(M1)
            Rb = random.randint(000000,999999)
            Ub = Rb + SKb
            M2 = str(Ub)
            connection.send(M2.encode())

            # 3. B compute the shared key Kb
            Kb1 = mul(c_p, c_q, c_n, G, Ua)
            Kb2 = neg(PKa, c_n)
            Kb3 = add(c_p, c_q, c_n, Kb1, Kb2)
            Kb = mul(c_p,c_q,c_n,Kb3,Rb)
            t1 = time.time()-t1
            print("The shared key is ",Kb)
            print("Time consumed on B is ",t1)
            token = 1

    except KeyboardInterrupt:
        print('>>>quit')
    #sys.exit(0)




