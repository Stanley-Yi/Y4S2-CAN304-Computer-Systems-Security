# coding=utf-8


class SecurityViolationException(Exception):
    pass
