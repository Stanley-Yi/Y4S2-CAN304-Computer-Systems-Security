# --- CAN304, CAN409 Lab  -----------------------------------------------------
# Lab 4: Advanced Cryptographic Schemes
#
# The lightweight protocol
# Party A
#
# COPYRIGHT (c) 2022 by Jie Zhang <jie.zhang01@xjtlu.edu.cn>
#
# -----------------------------------------------------------------------------

import errno
import socket
import time
import random

from collections import OrderedDict
from ecc.Key import Key
from ecc.elliptic import mul,add,neg

DOMAINS = {
    # Bits : (p, order of E(GF(P)), parameter b, base point x, base point y)

    256: (0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff,
          0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551,
          0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b,
          0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
          0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)
}

# longterm pk and sk
PKa = (19040945377468372801685031688616727966768327102472580671802632105133104724336, 38156029207146965564095933110433162116638889566634802199987175781928072746123)
SKa = 63635890968157518442188440425811602042870365597955099354657251300467671275350
# longterm pk of responder
PKb = (29846905600001464966663618133187015030164722551698089320692285893856188332202,112351487829443581875216157205261801929997742409482132786966528895913005612787)

if __name__== '__main__':

    global Ra,Tb,p,n,b,x,y,c_p,c_q,c_n,M1,M2,M3,Ka,macb
    server_ip = "127.0.0.1"
    server_port = 9002

    # initialization
    p, n, b, x, y = DOMAINS[256]
    c_p = 3
    c_n = p
    c_q = p - b
    G = (int(x), int(y))
    idA='00000001'
    idB='00000002'
    token=0

    
    # TCP connection to responder B
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setblocking(1)  
    print('begin connection')
    sock.connect((server_ip, server_port))
    
    try:
        while (token==0):
            print('connection up')
            print ('connected')
            
            # 1. A compute Ua, and send M1=(Ua) to B
            t1 = time.time()
            Ra = random.randint(000000, 999999)
            Ua = SKa + Ra
            
            M1=str(Ua)
            sock.send(M1.encode())
            t1 = time.time()-t1

            # 3. A receive M2, compute Ka
            M2 = sock.recv(1024).decode()
            t2 = time.time()
            Tbx = M2.split(',')[0]
            Tby = M2.split(',')[1]
            Tb = (int(Tbx), int(Tby))
            Ka1 = neg(PKb, c_n)
            Ka2 = add(c_p, c_q, c_n, Tb, Ka1)
            Ka = mul(c_p,c_q,c_n,Ka2,Ra)
            t2 = time.time()-t2
            print("The shared key is", Ka)
            print("Time consumed on A is", (t1+t2))
            token = 1

    except KeyboardInterrupt:
        print('>>>quit')
        #sock.close()
        #print("KeyboardInterrupt")
    #sys.exit(0)

    







