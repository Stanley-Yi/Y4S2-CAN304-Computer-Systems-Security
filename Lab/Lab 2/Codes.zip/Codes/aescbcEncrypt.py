# --- CAN304, CAN409 Lab  -----------------------------------------------------
# Lab 2: Learn to use Crypto libraries
#
# AES encrytion with the Cipher Block Chaining (CBC) mode
#
# COPYRIGHT (c) 2022 by Jie Zhang <jie.zhang01@xjtlu.edu.cn>
#
# -----------------------------------------------------------------------------

from Crypto.Cipher import AES

data = 'Learn cryptography with fun!'

# Add paddings to the plaintext so that the length is multiple of the cipher block size.
pad_len = AES.block_size - (len(data) % AES.block_size)
if pad_len != 0:
    data = data + chr(pad_len)*pad_len

# Let's assume that the key and iv are somehow available. Alternatively, you can generate the them using get_random_bytes()
# In real life, the key is negotiated between the encrypting and the decrypting entities. The iv must be “unpredictable”, in other words, randomly generated before the encryption starts. 
key = b'\xd6|iK\x8e\x94E\xd9\x82\x83,\xbap/\x8e\xdd'
iv = b'\xe5\x8f\x89V\x02\xddQz\xe9\x90SD\xd4\x90\xe8\xb6'


cipher = AES.new(key, AES.MODE_CBC, iv)
ciphertext = cipher.encrypt(data.encode('utf-8'))

print ("The ciphertext is: \n" + str(ciphertext))
